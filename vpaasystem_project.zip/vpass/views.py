from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Event, Attendance, CertificateTemplate
from django.http import HttpResponse
from django.conf import settings
from django.contrib.auth.models import User
import io, os

# certificate generation uses Pillow if installed
try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:
    Image = None

def home(request):
    return redirect('vpass:event_list')

@login_required
def event_list(request):
    events = Event.objects.all().order_by('-start')
    return render(request, 'vpass/event_list.html', {'events': events})

@login_required
def event_detail(request, pk):
    event = get_object_or_404(Event, pk=pk)
    attendees = Attendance.objects.filter(event=event)
    return render(request, 'vpass/event_detail.html', {'event': event, 'attendees': attendees})

@login_required
def scan_qr(request, event_id):
    # simplified: create or get attendance for the logged-in user
    event = get_object_or_404(Event, pk=event_id)
    attendance, created = Attendance.objects.get_or_create(event=event, user=request.user)
    if created:
        message = 'Timed in — attendance recorded.'
    else:
        message = 'Already timed in.'
    return render(request, 'vpass/scan_result.html', {'message': message, 'event': event})

@login_required
def generate_certificate(request, pk):
    event = get_object_or_404(Event, pk=pk)
    # pick default template
    template = CertificateTemplate.objects.filter(default=True).first()
    if Image is None or template is None:
        return HttpResponse('Pillow not installed or no certificate template found. Add a template in admin.', content_type='text/plain')
    template_path = os.path.join(settings.MEDIA_ROOT, template.image.name)
    if not os.path.exists(template_path):
        return HttpResponse('Template image missing on disk.', content_type='text/plain')

    # simple overlay: write username and event on the template and return image
    im = Image.open(template_path).convert('RGB')
    draw = ImageDraw.Draw(im)
    try:
        font = ImageFont.truetype('arial.ttf', 40)
    except Exception:
        font = ImageFont.load_default()
    text = f"{request.user.get_full_name() or request.user.username}\n{event.title}"
    w, h = draw.multiline_textsize(text, font=font)
    x = (im.width - w) // 2
    y = im.height - h - 150
    draw.multiline_text((x, y), text, font=font, align='center')
    buf = io.BytesIO()
    im.save(buf, format='PNG')
    buf.seek(0)
    return HttpResponse(buf.getvalue(), content_type='image/png')
