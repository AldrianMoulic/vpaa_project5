from django.apps import AppConfig
class VpassConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vpass'
