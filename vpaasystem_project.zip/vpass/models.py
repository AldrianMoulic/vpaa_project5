from django.db import models
from django.contrib.auth.models import User

class Event(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    start = models.DateTimeField()
    end = models.DateTimeField()
    location = models.CharField(max_length=200, blank=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.title

class Attendance(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    time_in = models.DateTimeField(auto_now_add=True)
    time_out = models.DateTimeField(null=True, blank=True)
    qr_code_data = models.CharField(max_length=500, blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.event.title}"

class CertificateTemplate(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='cert_templates/')
    default = models.BooleanField(default=False)

    def __str__(self):
        return self.name
