from django.urls import path
from . import views

app_name = 'vpass'

urlpatterns = [
    path('', views.home, name='home'),
    path('events/', views.event_list, name='event_list'),
    path('events/<int:pk>/', views.event_detail, name='event_detail'),
    path('events/<int:pk>/generate_certificate/', views.generate_certificate, name='generate_certificate'),
    path('scan/<int:event_id>/', views.scan_qr, name='scan_qr'),
]
