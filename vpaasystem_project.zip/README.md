# VPAA System - Minimal Django Project

This is a minimal ready-to-run Django project scaffold created by ChatGPT.

## Quick start

1. Create a virtualenv and install requirements:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # or .venv\Scripts\activate on Windows
   pip install -r requirements.txt
   ```
2. Run migrations and create superuser:
   ```bash
   python manage.py migrate
   python manage.py createsuperuser
   ```
3. (Optional) Add a CertificateTemplate in the admin and mark it default. Upload an image file.
4. Run the server:
   ```bash
   python manage.py runserver
   ```
5. Visit `http://127.0.0.1:8000/` and log in.

## Notes
- Certificate generation uses Pillow to open a template image (upload via admin) and overlay the user's name and event.
- QR scanning endpoint is simplified — it records attendance for the logged-in user.
